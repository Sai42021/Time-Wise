package com.example.flutcalendar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
